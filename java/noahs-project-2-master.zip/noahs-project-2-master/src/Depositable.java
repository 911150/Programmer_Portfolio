/** This is the Depositable interface.
 * @author Noah
 * @version 2
 */

public interface Depositable {
    // Interface ensuring functionality of Hoard's / Stockpiles
    void deposit();

}
