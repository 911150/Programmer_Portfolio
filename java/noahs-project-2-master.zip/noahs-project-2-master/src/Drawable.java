/** This is the Drawable interface.
 * @author Noah
 * @version 2
 */
public interface Drawable {
    // Drawable interface
    void draw();

}